---
Name: Custom Backgrounds
Creator: DanTheMan827
Category: UI
---
This mod will simply merge the main backgrounds folder with `/var/lib/clover/backgrounds` folder and you can use it to add custom borders without any additional modding.

## Notes and Known Issues

> When you uninstall this mod, it will remove all custom borders you've transferred to `/var/lib/clover/backgrounds`

> When you uninstall hakchi, it is possible that the custom borders stick. You can use the built-in `restore to factory settings` in your NES/SNES Mini to reset those as well!
